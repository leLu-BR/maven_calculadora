package testesjunit;

public class Main {
    public static void main(String[] args) {

        Calculadora c = new Calculadora();
        int soma1 = c.somaInteiros(3, 17);
        int subtrai1 = c.subtraiInteiros(45, 18);
        int multi1 = c.multiplicaInteiros(soma1, subtrai1);
        int divide1 = c.divideInteiros(soma1, 5);
        System.out.println("A soma é 3 + 17 = " + soma1 + "\n" +
                "A subtração é 45 - 18 = " + subtrai1 + "\n" +
                "A multiplicação é " + soma1 + " * " + subtrai1 + " = " + multi1 + "\n" +
                "A divisão é " + soma1 + " / 5 = " + divide1);
    }
}
