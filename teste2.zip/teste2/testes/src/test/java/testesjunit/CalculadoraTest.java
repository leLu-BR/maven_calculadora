package testesjunit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class CalculadoraTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    /*Testes da Soma */
    @Test
	public void doisSomaDoisEsperaQuatro() {
		Calculadora c = new Calculadora();
		assertEquals(4, c.somaInteiros(2, 2));
	}
	
	@Test
	public void tresSomaSeteEsperaDez() {
		Calculadora c = new Calculadora();
		assertTrue(c.somaInteiros(3, 7)==10);
		
	}

    @Test
    public void quatroSomaSeteEsperaOnze() {
        Calculadora c = new Calculadora();
        assertFalse(c.somaInteiros(4, 7) != 11);
    }

    /*Testes Subtração */
	@Test
	public void dezSubtraiDoisEsperaOito() {
		Calculadora c = new Calculadora();
		assertEquals(8, c.subtraiInteiros(10,2));
	}

	@Test
	public void dezesseteSubtraiDozeEsperaCinco() {
		Calculadora c = new Calculadora();
		assertTrue(c.subtraiInteiros(17, 12)==5);
	}

    @Test
    public void quinzeSubtraiOitoEsperaSete() {
        Calculadora c = new Calculadora();
        assertFalse(c.subtraiInteiros(15,8) != 7);
    }

    /*Testes Multiplicação */
	@Test
	public void doisMultiplicaSessentaEQuatroEsperaCentoEVinteOito() {
		Calculadora c = new Calculadora();
		assertEquals(128, c.multiplicaInteiros(2,64));
	}

	@Test
	public void tresMultiplicaQuatroEsperaDoze() {
		Calculadora c = new Calculadora();
		assertTrue(c.multiplicaInteiros(3, 4)==12);
	}

    @Test
    public void cincoMultiplicaSeisEsperaTrinta() {
        Calculadora c = new Calculadora();
		assertFalse(c.multiplicaInteiros(5, 6) != 30);
    }

    /*Testes Divisão */
	@Test
	public void trintaETresDivideOnzeEsperaTres() {
		Calculadora c = new Calculadora();
		assertEquals(3, c.divideInteiros(33,11));
	}

	@Test
	public void quarentaEDoisDivideTresEsperaQuatorze() {
		Calculadora c = new Calculadora();
		assertTrue(c.divideInteiros(42, 3)==14);
	}

    @Test
    public void cinquentaEUmDivideTresEsperaDezessete() {
		Calculadora c = new Calculadora();
		assertFalse(c.divideInteiros(51, 3) != 17);
	}

}
