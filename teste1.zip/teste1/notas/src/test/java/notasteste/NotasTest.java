package notasteste;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class NotasTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    @Test
	public void dezeNoveRetornaF(){
		Notas n = new Notas();
		assertEquals('F', n.retornaConceitoNota(Float.parseFloat("19.0")));
	}

	@Test
	public void vinteNoveRetornaE(){
		Notas n = new Notas();
		assertEquals('E', n.retornaConceitoNota(Float.parseFloat("29.0")));
	}

	@Test
	public void quarentaRetornaD() {
		Notas n = new Notas();
		assertEquals('D', n.retornaConceitoNota(Float.parseFloat("40.0")));
	}

	@Test
	public void cinquentaRetornaC() {
		Notas n = new Notas();
		assertEquals('C', n.retornaConceitoNota(Float.parseFloat("50.0")));
	}

	@Test
	public void sessentaNoveRetornaC() {
		Notas n = new Notas();
		assertEquals('C', n.retornaConceitoNota(Float.parseFloat("69.0")));
	}

	@Test
	public void setentaUmRetornaB() {
		Notas n = new Notas();
		assertEquals('B', n.retornaConceitoNota(Float.parseFloat("71.0")));
	}

	@Test
	public void oitentaNoveRetornaB() {
		Notas n = new Notas();
		assertEquals('B', n.retornaConceitoNota(Float.parseFloat("89.0")));
	}

	@Test
	public void noventaUmRetornaA() {
		Notas n = new Notas();
		assertEquals('A', n.retornaConceitoNota(Float.parseFloat("91.0")));
	}

	/*Testes adicionais de ponto de corte */

	@Test
	public void vinteRetornaE(){
		Notas n = new Notas();
		assertEquals('E', n.retornaConceitoNota(Float.parseFloat("20.0")));
	}

	@Test
	public void trintaRetornaD(){
		Notas n = new Notas();
		assertEquals('D', n.retornaConceitoNota(Float.parseFloat("30.0")));
	}

	
	@Test
	public void setentaRetornaB() {
		Notas n = new Notas();
		assertEquals('B', n.retornaConceitoNota(Float.parseFloat("70.0")));
	}

	@Test
	public void noventaRetornaA() {
		Notas n = new Notas();
		assertEquals('A', n.retornaConceitoNota(Float.parseFloat("90.0")));
	}
	@Test
	public void contextLoads() {
	}

}
