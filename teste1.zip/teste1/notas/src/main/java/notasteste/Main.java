package notasteste;

public class Main {
    public static void main(String[] args) {
        Notas n = new Notas();
        System.out.println(n.retornaConceitoNota(55.5f));
        System.out.println(n.retornaConceitoNota(79.8f)); 
        System.out.println(n.retornaConceitoNota(34.2f));
        System.out.println(n.retornaConceitoNota(98.7f)); 
    }
}
